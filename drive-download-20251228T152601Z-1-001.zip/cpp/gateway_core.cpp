#include <modbus/modbus.h>
#include <coap3/coap.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <ctime>
#include <cerrno>

#include <string>
#include <fstream>
#include <sstream>

#include <unistd.h>
#include <fcntl.h>

static std::string LOG_PATH = "/home/pi/modbus-coap-mqtt-gateway/logs/gateway_core.log";

static void log_line(const std::string& s) {
  std::ofstream f(LOG_PATH, std::ios::app);
  std::time_t now = std::time(nullptr);
  f << now << " " << s << "\n";
}

struct State {
  std::time_t ts = 0;
  float temp_c = 0.0f;
  float hum_pct = 0.0f;
};

static State g_state;
static modbus_t* g_modbus = nullptr;

static std::string json_state() {
  std::ostringstream os;
  os << "{\"ts\":" << (long)g_state.ts
     << ",\"temp_c\":" << g_state.temp_c
     << ",\"hum_pct\":" << g_state.hum_pct
     << "}";
  return os.str();
}

static void send_payload(coap_pdu_t* response,
                         const std::string& payload,
                         coap_pdu_code_t code = COAP_RESPONSE_CODE_CONTENT) {
  coap_pdu_set_code(response, code);
  coap_add_data(response, payload.size(), (const uint8_t*)payload.data());
}

// GET /sensors
static void h_sensors(coap_resource_t*, coap_session_t*, const coap_pdu_t*,
                      const coap_string_t*, coap_pdu_t* response) {
  auto payload = json_state();
  log_line("COAP GET /sensors " + payload);
  send_payload(response, payload);
}

// GET /sensors/temp
static void h_temp(coap_resource_t*, coap_session_t*, const coap_pdu_t*,
                   const coap_string_t*, coap_pdu_t* response) {
  std::ostringstream os;
  os << "{\"ts\":" << (long)g_state.ts << ",\"temp_c\":" << g_state.temp_c << "}";
  log_line("COAP GET /sensors/temp");
  send_payload(response, os.str());
}

// GET /sensors/hum
static void h_hum(coap_resource_t*, coap_session_t*, const coap_pdu_t*,
                  const coap_string_t*, coap_pdu_t* response) {
  std::ostringstream os;
  os << "{\"ts\":" << (long)g_state.ts << ",\"hum_pct\":" << g_state.hum_pct << "}";
  log_line("COAP GET /sensors/hum");
  send_payload(response, os.str());
}

// PUT /modbus/hreg/<addr>  payload: integer
static void h_hreg_put(coap_resource_t* resource, coap_session_t*,
                       const coap_pdu_t* request, const coap_string_t*,
                       coap_pdu_t* response) {
  const coap_str_const_t* uri = coap_resource_get_uri_path(resource);
  std::string path((const char*)uri->s, uri->length);  // modbus/hreg/0
  int addr = -1;
  auto pos = path.find_last_of('/');
  if (pos != std::string::npos) addr = std::atoi(path.c_str() + pos + 1);

  size_t size = 0;
  const uint8_t* data = nullptr;
  if (!coap_get_data(request, &size, &data) || addr < 0 || !g_modbus) {
    coap_pdu_set_code(response, COAP_RESPONSE_CODE_BAD_REQUEST);
    return;
  }

  int value = std::atoi(std::string((const char*)data, size).c_str());
  int rc = modbus_write_register(g_modbus, addr, (uint16_t)value);

  if (rc == 1) {
    log_line("COAP PUT /modbus/hreg/" + std::to_string(addr) + " value=" + std::to_string(value) + " OK");
    send_payload(response, "OK", COAP_RESPONSE_CODE_CHANGED);
  } else {
    log_line(std::string("COAP PUT failed: ") + modbus_strerror(errno));
    coap_pdu_set_code(response, COAP_RESPONSE_CODE_INTERNAL_ERROR);
  }
}

// stdin commands from Node: "SET_HREG <addr> <value>\n"
static void set_nonblocking_stdin() {
  int flags = fcntl(STDIN_FILENO, F_GETFL, 0);
  fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);
}

static void process_stdin_commands() {
  static std::string buf;
  char tmp[256];
  ssize_t n = read(STDIN_FILENO, tmp, sizeof(tmp));
  if (n <= 0) return;
  buf.append(tmp, tmp + n);

  size_t pos;
  while ((pos = buf.find('\n')) != std::string::npos) {
    std::string line = buf.substr(0, pos);
    buf.erase(0, pos + 1);

    int addr = -1, value = 0;
    if (std::sscanf(line.c_str(), "SET_HREG %d %d", &addr, &value) == 2 && addr >= 0 && g_modbus) {
      int rc = modbus_write_register(g_modbus, addr, (uint16_t)value);
      if (rc == 1) log_line("STDIN SET_HREG " + std::to_string(addr) + " " + std::to_string(value) + " OK");
      else log_line(std::string("STDIN SET_HREG failed: ") + modbus_strerror(errno));
    }
  }
}

int main(int argc, char** argv) {
  const char* dev = (argc > 1) ? argv[1] : "/dev/ttyUSB0";
  int slave_id = (argc > 2) ? std::atoi(argv[2]) : 1;

  // ---- Modbus ----
  modbus_t* ctx = modbus_new_rtu(dev, 9600, 'N', 8, 1);
  if (!ctx) return 1;
  g_modbus = ctx;

  modbus_set_slave(ctx, slave_id);
  struct timeval to {1, 0};
  modbus_set_response_timeout(ctx, to.tv_sec, to.tv_usec);

  if (modbus_connect(ctx) != 0) {
    std::fprintf(stderr, "modbus_connect failed: %s\n", modbus_strerror(errno));
    return 2;
  }
  log_line(std::string("Modbus connected dev=") + dev + " slave=" + std::to_string(slave_id));

  // ---- CoAP ----
  coap_startup();
  coap_set_log_level(COAP_LOG_ERR);

  coap_context_t* coap_ctx = coap_new_context(nullptr);
  if (!coap_ctx) return 3;

  coap_address_t addr;
  coap_address_init(&addr);
  addr.addr.sa.sa_family = AF_INET;
  addr.addr.sin.sin_port = htons(5683);

  coap_endpoint_t* ep = coap_new_endpoint(coap_ctx, &addr, COAP_PROTO_UDP);
  if (!ep) return 4;

  // resources
  coap_resource_t* r1 = coap_resource_init(coap_make_str_const("sensors"), 0);
  coap_register_handler(r1, COAP_REQUEST_GET, h_sensors);
  coap_add_resource(coap_ctx, r1);

  coap_resource_t* r2 = coap_resource_init(coap_make_str_const("sensors/temp"), 0);
  coap_register_handler(r2, COAP_REQUEST_GET, h_temp);
  coap_add_resource(coap_ctx, r2);

  coap_resource_t* r3 = coap_resource_init(coap_make_str_const("sensors/hum"), 0);
  coap_register_handler(r3, COAP_REQUEST_GET, h_hum);
  coap_add_resource(coap_ctx, r3);

  for (int i = 0; i < 2; i++) {
    std::string p = "modbus/hreg/" + std::to_string(i);
    coap_resource_t* r = coap_resource_init(coap_make_str_const(p.c_str()), 0);
    coap_register_handler(r, COAP_REQUEST_PUT, h_hreg_put);
    coap_add_resource(coap_ctx, r);
  }

  log_line("CoAP started udp/5683");
  set_nonblocking_stdin();

  uint16_t regs[2];
  std::time_t last_poll = 0;

  while (true) {
    coap_io_process(coap_ctx, 50);
    process_stdin_commands();

    std::time_t now = std::time(nullptr);
    if (now != last_poll) {
      last_poll = now;

      int rc = modbus_read_registers(ctx, 0, 2, regs);
      if (rc == 2) {
        int16_t t10 = (int16_t)regs[0];
        g_state.ts = now;
        g_state.temp_c = ((float)t10) / 10.0f;
        g_state.hum_pct = ((float)regs[1]) / 10.0f;

        std::string js = json_state();
        std::printf("%s\n", js.c_str());
        std::fflush(stdout);

        log_line("Modbus poll OK " + js);
      } else {
        log_line(std::string("Modbus poll FAIL: ") + modbus_strerror(errno));
      }
    }
  }
}
