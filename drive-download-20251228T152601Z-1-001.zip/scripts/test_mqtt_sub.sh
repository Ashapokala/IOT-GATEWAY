#!/usr/bin/env bash
mosquitto_sub -t 'gateway/pi1/#' -v
