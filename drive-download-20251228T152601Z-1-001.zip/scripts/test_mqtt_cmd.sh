#!/usr/bin/env bash
mosquitto_pub -t 'gateway/pi1/cmd/hreg/0' -m '300'
