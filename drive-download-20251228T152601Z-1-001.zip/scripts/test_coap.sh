#!/usr/bin/env bash
coap-client-notls -m get coap://127.0.0.1/sensors
coap-client-notls -m put -e "305" coap://127.0.0.1/modbus/hreg/0
