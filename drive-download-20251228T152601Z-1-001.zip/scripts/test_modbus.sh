#!/usr/bin/env bash
sudo mbpoll -0 -m rtu -a 1 -b 9600 -P none -t 4 -r 0 -c 2 /dev/ttyUSB0
