const { spawn } = require("child_process");
const mqtt = require("mqtt");
const fs = require("fs");

const SERIAL_DEV = process.env.SERIAL_DEV || "/dev/ttyUSB0";
const SLAVE_ID = process.env.SLAVE_ID || "1";
const MQTT_URL = process.env.MQTT_URL || "mqtt://localhost:1883";

const LOG_FILE = "/home/pi/modbus-coap-mqtt-gateway/logs/mqtt_bridge.log";
function log(msg) {
  fs.appendFileSync(LOG_FILE, `${Date.now()} ${msg}\n`);
}

let latest = { ts: 0, temp_c: null, hum_pct: null };

const core = spawn("/home/pi/modbus-coap-mqtt-gateway/cpp/build/gateway_core",
  [SERIAL_DEV, SLAVE_ID],
  { stdio: ["pipe", "pipe", "pipe"] }
);

core.stdout.on("data", (buf) => {
  buf.toString().trim().split("\n").forEach((line) => {
    try { latest = JSON.parse(line); } catch {}
  });
});

core.stderr.on("data", (buf) => log("CORE_ERR " + buf.toString()));
core.on("exit", (code) => log("CORE_EXIT " + code));

const client = mqtt.connect(MQTT_URL);

client.on("connect", () => {
  log("MQTT connected " + MQTT_URL);

  // commands topic: gateway/pi1/cmd/hreg/<addr>
  client.subscribe("gateway/pi1/cmd/hreg/+", (err) => {
    if (err) log("SUB_ERR " + err.message);
  });

  // publish telemetry every 5s
  setInterval(() => {
    const topic = "gateway/pi1/telemetry";
    client.publish(topic, JSON.stringify(latest));
    log("PUB " + topic + " " + JSON.stringify(latest));
  }, 5000);
});

client.on("message", (topic, message) => {
  const payload = message.toString().trim();
  const addr = parseInt(topic.split("/").pop(), 10);
  const value = parseInt(payload, 10);

  if (Number.isInteger(addr) && Number.isInteger(value)) {
    core.stdin.write(`SET_HREG ${addr} ${value}\n`);
    log(`CMD SET_HREG ${addr} ${value}`);
  } else {
    log(`BAD_CMD topic=${topic} payload=${payload}`);
  }
});
